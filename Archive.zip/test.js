var http = require('http');
var server = http.createServer();
server.on('request', function(request, response) {
  // the same kind of magic happens here!

});
